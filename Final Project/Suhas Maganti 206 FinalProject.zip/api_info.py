## SI 206 2017
## Final Project
## Name: Suhas Maganti



####Instagram Info
client_id = "a5614a76dca6446c8c49ab793b3769fe"
client_secret = "f2f7a1804b584bc69f11628e42d5c385"
redirect_uri = "https://www.google.com/"
scope = ['basic', 'comments', 'follower_list', 'likes', 'public_content']
code = "c1fe9c41659740f09fc110fcb7e6870b"

insta_token = "1420219052.a5614a7.7f67441564634eb5bf0805513e6fd89a"

####Facebook Info

fb_token = "EAACEdEose0cBANZA0rT9a32XRylRswdoubWc3Pj00nfguhqHIHDU44JpPKKdRgrlZBqDZBJ34xsx0DYxk5aFEZCeG5AHZAxtwkJXhBpJJnIOdGSEZBAPwxpPA0iZBibuTDaQ9SFcyTby8QZCpyUMXDe5LtkiVTq7L1KT5iw5zTa3jCls44UjiILZBUUBNOlPUxYpDEQNuV1F73wZDZD"

####Plotly Info

api_key = "KjnKgHU2UFZFrwopG07o"